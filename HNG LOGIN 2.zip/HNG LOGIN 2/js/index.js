// const guideList = document.querySelector('.guides');

// //setup guides
// const setupGuides = (data) => {
//     let html = '';
//     data.forEach(doc => {
//         const guide = doc.data();
//         const hng = `
//         <div>
//           <h2>${guide.title}</h2>
//           <h3>${guide.content}</h2>
//         </div>
//         `;
//         html += hng
//     });
    
//     guideList.innerHTML = html;
    
// }

